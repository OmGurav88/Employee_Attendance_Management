package com.om.cls;

import java.io.Console;
import java.io.IOException;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Time;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.InputMismatchException;
import java.util.Scanner;


/**
 * This is entry point for the employee attendance management system
 * This method performs login and displays a menu of options for the employee to
 * choose and interact with the system
 * @author Team1
 * 
 * 
 */
public class Main {
	
	public static void main(String[] args) throws SQLException, IOException {
		
		EmpDAOImpl e = new EmpDAOImpl();
        Scanner sc = new Scanner(System.in);
        
        String reset = "\033[0m";  // Reset to default
        String blue = "\033[1;34m"; // Blue for headers and login success.
        String red = "\033[1;31m";  // Red for errors
        String green = "\033[1;32m"; // Green for success
        String yellow = "\033[1;33m"; // Yellow for the menu title
        
        // Print welcome message with color
        int flag1=0;
        while(flag1==0) {
        	
        
        System.out.println(yellow + "\n\n********** Welcome to login system **********" + reset);
        System.out.println(blue + "==============================================" + reset);
        
        // Prompt for username
        System.out.print(blue + "Enter username: " + reset);
        String username = sc.nextLine();
        System.out.println(blue + "----------------------------------------------" + reset);
        
        // Prompt for password
        Console console = System.console();
        System.out.print(blue + "Enter password: " + reset);
        String password = sc.nextLine();

        
        boolean isAuthenticated = e.authenticate(username, password);
        int flag=0;

        if (isAuthenticated) {
            System.out.println(blue + "=============================================" + reset);
            System.out.println(green + "Login successful!" + reset); // Green success message
            
        } else {
            System.out.println(red + "Please enter valid Username and password\\nLogin Unsuccesfull" + reset); // Red error message
            flag=1;
           
        }
		while(true && flag==0) {
			System.out.println(yellow + "\n============== Employee Management System ==========" + reset + "\n");
	        System.out.println(green + "1. View my Profile" + reset);
	        System.out.println(green + "2. Mark Attendance" + reset);
	        System.out.println(green + "3. View Attendance History" + reset);
	        System.out.println(green + "4. Generate Report" + reset);
	        System.out.println(green + "5. Exit" + reset);
	        
	        //for getting employee id of username
	        int empId= e.getEmpId(username);
	        

	        // Prompt for user input	        
	        System.out.print(blue + "Enter your choice: " + reset);

            int c = -1; // Default invalid choice
            try {
                // Validate that the input is numeric
                c = sc.nextInt();
            } catch (InputMismatchException e3) {
                System.out.println(red + "Invalid input. Please enter a numeric value." + reset);
                sc.nextLine(); // Clear the invalid input
                continue; // Restart the loop
            }
            switch(c) {
                        
            case 1: 
            	//View Details
            	System.out.println("\n============== View Profile ==========\n");
                e.viewProfile(username);
                break;
            
             
            case 2:
            	//markAttendance
            	System.out.println("\n============== Mark Attendance ==========\n");

 	           LocalDate today = LocalDate.now();
 	           LocalDate date = null;

	            // Validate the entered date.
 	          while (true) {
 	        	    try {
 	        	        System.out.print("Enter Attendance Date (YYYY-MM-DD): ");
 	        	        date = LocalDate.parse(sc.next());

 	        	        if (date.isAfter(today)) {
 	        	            System.out.println(red+"Please enter a valid date. Future dates are not allowed."+reset);
 	        	            continue; // Loop again for valid input
 	        	        }
 	        	       else if (date.isBefore(today)) {
 	        	            System.out.println(red + "Please enter today's date only. Previous dates are not allowed." + reset);
 	        	            continue; // Loop again for valid input
 	        	        }
 	        	        break; // Valid date entered
 	        	    } catch (Exception e1) {
 	        	        System.out.println(red+"Invalid date format. Please enter in YYYY-MM-DD format."+reset);
 	        	    }
 	        	}
	            
 	            //Date date = Date.valueOf(sc.next()); 	            
 	            String checkQuery = "SELECT COUNT(*) FROM attendance WHERE emp_id = ? AND a_date = ?";                 
 	           LocalTime checkIn = null, checkOut = null;
               while (true) {
                   try {
                       System.out.print("Enter Check-In Time (24 hours format) (HH:MM:SS): ");
                       checkIn = LocalTime.parse(sc.next());

                       System.out.print("Enter Check-Out Time (24 hours format) (HH:MM:SS): ");
                       checkOut = LocalTime.parse(sc.next());

                       // Validate logical order
                       if (checkOut.isBefore(checkIn)) {
                           System.out.println(red+"Check-Out time must be after Check-In time. Please re-enter."+reset);
                           continue; // Re-prompt for times
                       }
                       break; // Valid times entered
                   } catch (Exception e1) {
                       System.out.println(red+"Invalid time format. Please enter times in HH:MM:SS format."+reset);
                   }
               }
                   e.markAttendance(empId, date, checkIn, checkOut, checkQuery);
   	            	break;            
 	            
            	
            case 3:
                // View Attendance
                System.out.println("\n============== Attendance Report ==========\n");

                // Validate start date input
                Date startDate = null;
                Date endDate = null;

                while (true) {
                    try {
                        System.out.print("Enter Start Date (yyyy-mm-dd): ");
                        startDate = Date.valueOf(sc.next());  // This will throw an exception if the format is wrong
                        System.out.print("Enter End Date (yyyy-mm-dd): ");
                        endDate = Date.valueOf(sc.next());  // This will throw an exception if the format is wrong
                        break;  // Exit the loop if the date format is correct
                    } catch (IllegalArgumentException e6) {
                        System.out.println("Invalid date format. Please enter in yyyy-mm-dd format.");
                    }
                }

                // Validate end date input
//                Date endDate = null;
//                while (true) {
//                    try {
//                        System.out.print("Enter End Date (yyyy-mm-dd): ");
//                        endDate = Date.valueOf(sc.next());  // This will throw an exception if the format is wrong
//                        break;  // Exit the loop if the date format is correct
//                    } catch (IllegalArgumentException e) {
//                        System.out.println("Invalid date format. Please enter in yyyy-mm-dd format.");
//                    }
//                }

                // Assuming empId is already obtained or is available
                e.viewAttendance(empId, startDate, endDate);
                break;

            
//            case 4:
//            	//generate summary.
//            	System.out.println("\n============== Generating report ==========\n");
////            	 System.out.print("Enter Employee ID: ");
//// 	            int empId1 = sc.nextInt();
//
// 	            System.out.print("Enter Month (YYYY-MM): ");
// 	            String month = sc.next();
//
// 	            String sd1 = month + "-01";
// 	            String ed1 = month + "-31";
// 	            e.generateSummary(empId,month,sd1,ed1);  //int e, String m, String st, String ed
// 	            break;
// 	            
            case 4:
                // Generate summary
                System.out.println("\n============== Generating report ==========\n");

                // Validate month input
                String month = null;
                while (true) {
                    System.out.print("Enter Month (YYYY-MM): ");
                    month = sc.next();

                    // Validate that the month is in the correct format
                    if (month.matches("\\d{4}-\\d{2}")) {  // Regex to match YYYY-MM format
                        // Check if the entered month is valid (i.e., between 01 and 12)
                        int monthNum = Integer.parseInt(month.split("-")[1]);
                        if (monthNum >= 1 && monthNum <= 12) {
                            break;  // Exit the loop if the format is correct
                        } else {
                            System.out.println("Invalid month! Please enter a valid month between 01 and 12.");
                        }
                    } else {
                        System.out.println("Invalid format! Please enter the month in YYYY-MM format.");
                    }
                }

                // Construct the start and end date for the month
                String sd1 = month + "-01";
                String ed1 = month + "-31";

                // Call the generateSummary method
                e.generateSummary(empId, month, sd1, ed1);  // Pass the employee ID, month, and date range

                break;

            case 5:
                System.out.println("\nExiting the system. Goodbye!");
                sc.close();
                flag=1;
                return;
                
            default:
                System.out.println("Invalid choice! Please try again.");
        
            }
            
            }
            
        }
        
	}

}
		
		
		


	
		
	


