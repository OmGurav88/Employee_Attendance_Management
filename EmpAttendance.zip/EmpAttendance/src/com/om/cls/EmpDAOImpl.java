package com.om.cls;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

/**
 * 
 * Implementation of the {@code IEmpDAO} interface to manage employee data.
 * This class handles database connectivity and performing operations such as
 * viewing profile, marking attendance and generating reports
 * @author Om Gurav,Prathyusha,Krishna
 * 
 * 
 */
public class EmpDAOImpl implements IEmpDAO {
	
	/**
	 * Static block to initialize the database connection and execute SQL queries.
	 * Make sure to configure the database connection properties before using this class.
	 * 
	 */
	static Properties props = null;
	static Connection conn = null;
	static {
		try {
			String paths = "C:\\Users\\localadmin\\Downloads\\Project\\EmpAttendance1\\src\\app.properties";
			FileReader reader = new FileReader(new String(paths));
			props = new Properties();
			props.load(reader);
			// Load the driver
			Class.forName(props.getProperty("drivername"));
			conn = DriverManager.getConnection(props.getProperty("conn"), props.getProperty("username"),
					props.getProperty("password"));
		} catch (IOException | ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	/**
	 * Employee can view profile from here.
	 * @author OmGurav
	 * @param empId
	 */
	public void viewProfile(String username ) {
		
		String query="SELECT e.emp_id, e.emp_name, e.emp_email, e.emp_phoneno, e.emp_jd, d.dept_name,e.manager from employees e JOIN departments d ON e.dept_id = d.dept_id JOIN users u ON u.login_id=e.emp_id where u.username=?";
		try {
			PreparedStatement stmt=conn.prepareStatement(query);
			stmt.setString(1, username);
			ResultSet rs=stmt.executeQuery();
			if(rs.next()) {
			
//				System.out.println("Employee ID: " + rs.getInt("emp_id"));
//                System.out.println("Name: " + rs.getString("emp_name"));
//                System.out.println("Email: " + rs.getString("emp_email"));
//                System.out.println("Phone Number: " + rs.getString("emp_phoneno"));
//                System.out.println("Joining Date: " + rs.getDate("emp_jd"));
//                System.out.println("Department: " + rs.getString("dept_name"));
//                System.out.println("Manager: " + rs.getString("manager"));
				// Define the table header
                String[] columns = {"EmployeeID", "Name", "Email", "PhoneNumber", "JoiningDate", "Dept","Manager"};

                // Define the data for the table row
                Object[][] data = {
                    {
                        rs.getInt("emp_id"),
                        rs.getString("emp_name"),
                        rs.getString("emp_email"),
                        rs.getString("emp_phoneno"),
                        rs.getDate("emp_jd"),
                        rs.getString("dept_name"),
                        rs.getString("manager")
                    }
                };
             // Print the table
                ConsoleTableFormatter.printTable(columns, data);                
			}
			else {
                System.out.println("No employee found with username: " + username);
            }
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	
	
	/**
	 * Marks the attendance for an employee on a specific date.
	 * @param empId,date,checkIn,checkOut,checkQuery 
	 * @author  Prathyusha
	 * 
	 */
    @Override
	public void markAttendance(int empId,LocalDate date,LocalTime checkIn,LocalTime checkOut,String checkQuery) throws SQLException {
		 try  { 				
			 
			 ///////////Duplicate entries////////////
			 
			 //
			PreparedStatement checkStmt = conn.prepareStatement(checkQuery);
		   checkStmt.setInt(1, empId);
          checkStmt.setDate(2, Date.valueOf(date));

          ResultSet rs = checkStmt.executeQuery();
          rs.next(); // Move the cursor to the first row
          int count = rs.getInt(1);

          if (count > 0) {
              System.out.println("Attendance already exists for Employee ID: " + empId + " on " + Date.valueOf(date));
              return; // Exit the method to prevent duplicate insertion
          }
			 /////////////////////
          
          String status;
           long durationInMinutes = java.time.Duration.between(checkIn, checkOut).toMinutes();
           long durationInHours = durationInMinutes / 60;

           if (checkIn.isAfter(LocalTime.of(11, 0))) {
               status = "Late";
           } else if (durationInHours >= 5) {
               status = "Present";
           } else {
               status = "Half day";
           }

	            String query = "INSERT INTO attendance (emp_id, a_date, a_checkin, a_checkout, status) " +
	                    "VALUES ( ?, ?, ?, ?, ?)";

	            try (PreparedStatement stmt = conn.prepareStatement(query)) {
	            	
	                stmt.setInt(1, empId);
	                stmt.setDate(2, Date.valueOf(date));
	                stmt.setTime(3, Time.valueOf(checkIn));
	                stmt.setTime(4, Time.valueOf(checkOut));
	                stmt.setString(5, status);

	                stmt.executeUpdate();
	                System.out.println("Attendance marked successfully.");
	            }

	        } catch (SQLException e) {
	            System.err.println("Error: " + e.getMessage());
	        }

	}
    

/**
 * Views the attendance history for a given employee over a specified date range.
 * @param emp_id,start_date,end_date
 * @author SaiKrishna
 * 
 */
	
	@Override
	public void viewAttendance(int eid, Date sd, Date ed ) throws SQLException {

	            String query = "SELECT * FROM attendance " +
	                    "WHERE emp_id = ? AND a_date BETWEEN ? AND ? " +
	                    "ORDER BY a_date";

	            try (PreparedStatement stmt = conn.prepareStatement(query)) {
	                stmt.setInt(1, eid);
	                stmt.setDate(2, sd);
	                stmt.setDate(3, ed);

	                ResultSet rs = stmt.executeQuery();
	                String[] columns = {"Date", "Check-In", "Check-Out", "Status"};
		            List<Object[]> rows = new ArrayList<>();


		            while (rs.next()) {
		                rows.add(new Object[] {
		                    rs.getDate("a_date"),
		                    rs.getTime("a_checkin"),
		                    rs.getTime("a_checkout"),
		                    rs.getString("status")
		                });
		            }

		            Object[][] data = new Object[rows.size()][4];
		            rows.toArray(data);

		            // Print the table
		            ConsoleTableFormatter.printTable(columns, data);
	            }        

	}
    
	/**
     * Generates an attendance summary for an employee over a specific month.
     * @param empid,month,s_date,e_date
     * @author Akanksha
     */
	@Override
	public void generateSummary( int eid, String m, String sd, String ed) throws SQLException {

	            String query = "SELECT " +
	                    "COUNT(CASE WHEN status IN ('Present', 'Late') THEN 1 END) AS total_working_days, " +
	                    "COUNT(CASE WHEN status = 'Absent' THEN 1 END) AS total_absent_days " +
	                    "FROM attendance " +
	                    "WHERE emp_id = ? AND a_date BETWEEN ? AND ?";

	            try (PreparedStatement stmt = conn.prepareStatement(query)) {
	                stmt.setInt(1, eid);
	                stmt.setDate(2, Date.valueOf(sd));
	                stmt.setDate(3, Date.valueOf(ed));

	                ResultSet rs = stmt.executeQuery();
	             // Print table header
		            String[] columns = {"Total Working Days","Present Days", "Absent Days"};		            
	                if (rs.next()) {
	                	// Define data to be displayed in table
	                	int presentDays= rs.getInt("total_working_days") - rs.getInt("total_absent_days");
		                Object[][] data = {
		                    {
		                        rs.getInt("total_working_days"),
		                        presentDays,
		                        rs.getInt("total_absent_days")
		                        
		                    }
		                };

		                // Print formatted table
		                ConsoleTableFormatter.printTable(columns, data);

	                } else {
	                    System.out.println("No attendance records found.");
	                }
	            }

	        }
	
	
	 /**
     * Authenticates a user based on the provided username and password.
     * @param username,password
     * @return true if the authentication is successful, otherwise false
     * @author Avinash
     */
	@Override
    public boolean authenticate(String username, String password) {
        String query = "SELECT * FROM users WHERE username = ? AND password = ?";
        try (PreparedStatement statement = conn.prepareStatement(query)) {
            statement.setString(1, username);
            statement.setString(2, password);

            ResultSet resultSet = statement.executeQuery();
            
            if (resultSet.next()) {
//                storeLoginTime(username);
                return true;
            }
            if (!resultSet.next()) {
                System.out.println("No user found with provided credentials.");
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false; 
    }

	
	/**
	 * Stores the login time of employee
	 * @param username 
	 * @author Avinash
	 */
    private void storeLoginTime(String username) {
        String query = "UPDATE users SET login_time = ? WHERE username = ?";

        try (PreparedStatement statement = conn.prepareStatement(query)) {
            Timestamp loginTime = Timestamp.valueOf(LocalDateTime.now());
            statement.setTimestamp(1, loginTime);
            statement.setString(2, username);
            statement.executeUpdate(); 
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    /**
	 * Stores the logout time of employee
	 * @param username 
	 * @author Avinash
	 */
    public void storeLogoutTime(String username) {
        String query = "UPDATE users SET logout_time = ? WHERE username = ?";

        try (PreparedStatement statement = conn.prepareStatement(query)) {
            
            Timestamp logoutTime = Timestamp.valueOf(LocalDateTime.now());
            statement.setTimestamp(1, logoutTime);
            statement.setString(2, username);
            statement.executeUpdate(); 
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    /**
   	 * Displays the logged in employee
   	 * @param username 
   	 * @author Avinash
   	 */
    public void displayLoggedInUsers() {
        String query = "SELECT * FROM users WHERE login_time IS NOT NULL AND logout_time IS NULL";

        try (Statement statement = conn.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {

            while (resultSet.next()) {
                int id = resultSet.getInt("login_id");
                String username = resultSet.getString("username");
                Timestamp loginTime = resultSet.getTimestamp("login_time");

                System.out.println("LoginId: " + id + ", Username: " + username + ", Login Time: " + loginTime);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public void logout(String username) {
        storeLogoutTime(username);  
    }


    public int getEmpId(String username) {
        int empId = -1;
        

        try {
            
            // SQL query to retrieve employee ID based on username
            String sql = "SELECT login_id FROM users WHERE username = ?";
            
            PreparedStatement preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setString(1, username);

            // Execute the query
            ResultSet resultSet  = preparedStatement.executeQuery();

            // Retrieve the employee ID
            if (resultSet.next()) {
            	empId = resultSet.getInt("login_id");
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Handle exception
        } 
        return empId; // Return the employee ID
    }


	

}
