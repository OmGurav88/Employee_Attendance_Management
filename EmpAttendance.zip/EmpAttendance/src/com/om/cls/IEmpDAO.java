package com.om.cls;

import java.sql.Date;
import java.sql.SQLException;
import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalTime;

/**
 * Interface Class which defines methods for employee attendance system
 * The methods in this interface are implemented by EmpDAOImpl class
 * @author OmGurav
 */
public interface IEmpDAO {
	
	void viewProfile(String username);
	
	void markAttendance(int empId, LocalDate date, LocalTime checkIn, LocalTime checkOut, String checkQuery)
			throws SQLException;

    void viewAttendance(int eid, Date sd, Date ed) throws SQLException;

    void generateSummary(int e, String m, String sd, String ed) throws SQLException;

	boolean authenticate(String username, String password);

}
