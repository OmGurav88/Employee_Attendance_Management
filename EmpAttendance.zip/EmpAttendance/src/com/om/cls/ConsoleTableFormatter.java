package com.om.cls;

public class ConsoleTableFormatter {
	
	    
	

	    public static void printTable(String[] columns, Object[][] data) {
	        // Print the header row
	        printRow(columns);
	        
	        // Print separator line
	        printSeparator(columns.length);
	        
	        // Print each data row
	        for (Object[] row : data) {
	            printRow(row);
	        }
	    }
	    
	    // Method to print a single row
	    private static void printRow(Object[] row) {
	        for (Object cell : row) {
	            System.out.printf("%-30s", cell); // Adjusts the column width to 20 characters
	        }
	        System.out.println(); // Moves to the next line after printing a row
	    }

	    // Method to print separator line
	    private static void printSeparator(int columnCount) {
	        for (int i = 0; i < columnCount; i++) {
	            System.out.print("--------------------------"); // Separator line for each column
	        }
	        System.out.println();
	    }
	    
	    public static void main(String[] args) {
	        // Test data
	        String[] columns = {"Date", "Check-In", "Check-Out", "Status"};
	        Object[][] data = {
	            {"2024-12-01", "09:00:00", "17:00:00", "Present"},
	            {"2024-12-02", "10:00:00", "17:00:00", "Late"},
	            {"2024-12-03", "09:15:00", "16:45:00", "Half Day"}
	        };
	        
	        // Print the table
	        printTable(columns, data);
	    }
	}

	



