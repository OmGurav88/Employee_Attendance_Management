package com.sat.cls;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.TreeMap;

//Hashmap
public class Main {

	public static void main(String[] args) {
//		HashMap();
		
		//LinkedHAshmap  it is very slow
//		LinkedHashmap();
		
		//TreeMap it will sort on the basis of keys and not value in key-value combination
		int [] ar1 = {91,24,399,41};
		String[] ar2 = {"om","risheel","giri","Ayush"};
		TreeMap<Integer, String> tm = new TreeMap<>();
		for(int i=0;i<ar1.length;i++) {
			tm.put(ar1[i], ar2[i]);
		}
		System.out.println("Treemap - "+tm);
		
		Iterator it = tm.entrySet().iterator();
		while(it.hasNext()) {
			Entry<Integer,String> ent = (Entry<Integer,String>) it.next();
			System.out.println(ent.getKey()+" - "+ ent.getValue());
		}
		
		
		
		
	}

	private static void LinkedHashmap() {
		int [] ar1 = {1,2,3,4};
		String[] ar2 = {"om","risheel","giri","Ayush"};
		LinkedHashMap<Integer, String> lhm = new LinkedHashMap<>();
		for(int i=0;i<ar1.length;i++) {
			lhm.put(ar1[i], ar2[i]);
		}
//		System.out.println(lhm);
		
		//printing
		Iterator it = lhm.entrySet().iterator();
		while(it.hasNext()) {
//			System.out.println(it.next());
			Entry<Integer, String> ent = (Entry<Integer,String> )it.next();
			System.out.println(ent.getKey()+" - "+ ent.getValue());
			
		}
		//try using keySet
		
		
	}

	private static void HashMap() {
		HashMap<Integer,String> hs = new HashMap<>();
		int [] ar1 = {1,2,3,4};
		String[] ar2 = {"om","risheel","giri","Ayush"};
		for(int i=0;i<ar1.length;i++) {
			hs.put(ar1[i], ar2[i]);
		}
		System.out.println(hs);
		
		System.out.println("\n***********Using Arrays***********");
		List ar3 = Arrays.asList(hs.entrySet());
		for(Object a:ar3) {
			System.out.println(a);
		}
		System.out.println("\n***********trying to modify hashmap***********");
		hs.put(23, "Rahul");
		System.out.println(hs);//trying to modify
		
		System.out.println("\n***********\nUsing iterator***********");
		Iterator it = hs.entrySet().iterator();
		
//		System.out.println("\n***********trying to modify hashmap inside an iterator***********");
//		hs.put(23, "Rahul");//trying to modify; it throws an error
//		System.out.println(hs);
		while(it.hasNext()) {
			System.out.println(it.next());
		}
		System.out.println("\n***********Using iterator 2nd method ***********");
		Iterator itra=hs.keySet().iterator();
		while(itra.hasNext()) {
			Object key=itra.next();
			System.out.println(key+" "+hs.get(key));
		}
		System.out.println("************************");
		Iterator itrb=Arrays.asList(hs.entrySet()).iterator();
		while(itrb.hasNext()) {
			System.out.println(itrb.next());
		}
	}

}
