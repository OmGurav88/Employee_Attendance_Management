package com.cls;

import java.util.Comparator;

//public class StudentSorter implements Comparator<Student> {
public class StudentSorter implements Comparator<Employee>{

	@Override
	public int compare(Employee o1, Employee o2) {
		// TODO Auto-generated method stub
//		return o1.getSid() - o2.getSid();
		return o1.getEsal() - o2.getEsal();
	}
	
}
