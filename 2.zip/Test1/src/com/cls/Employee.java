package com.cls;

public class Employee {
	private int eid;
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public int getEsal() {
		return esal;
	}
	public void setEsal(int ar3) {
		this.esal = ar3;
	}
	private String ename;
	private int esal;
	
	@Override
	public String toString() {
		return this.eid + "-"+ this.ename + "-" + this.esal;
	}
	
	
}
