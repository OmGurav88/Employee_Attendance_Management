package com.cls;

public class Player {
	private int pid;
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public Player() {
		
	}
	public Player(int pid, String pname, int prank, String state) {
		super();
		this.pid = pid;
		this.pname = pname;
		this.prank = prank;
		this.state = state;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public int getPrank() {
		return prank;
	}
	public void setPrank(int prank) {
		this.prank = prank;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	private String pname;
	private int prank;
	private String state;
	
	@Override
	public String toString() {
		return this.pid + "-"+ this.pname + "-" + this.prank + "-" + this.state;
	}
	
}
