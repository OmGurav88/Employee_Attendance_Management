package com.tt;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class MyMain {

	public static void main(String[] args) {
		try {
			Class.forName("org.postgresql.Driver");
			Connection conn=DriverManager.getConnection("jdbc:postgresql://localhost:5432/TrialDB", "postgres", "om");
			
			//insert into DB
			//PreparedStatement ps = conn.prepareStatement("insert into public.\"Register\" values (11,'srk','srk@gmail.com')");
//			ps.execute();
			
			//Update into Db
//			PreparedStatement ps = conn.prepareStatement("update public.\"Register\" set rname='salman',rimage='sallu@gmail.com' where rid=11");
//			ps.executeUpdate();
			
			//Delete in Db
			
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
