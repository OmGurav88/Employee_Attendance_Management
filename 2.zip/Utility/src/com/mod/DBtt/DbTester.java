package com.mod.DBtt;

import java.util.Iterator;
//import java.util.List;
import java.util.List;

import com.mod.Register;
import com.mod.DButils.DButils;
//import com.sun.tools.javac.util.List;


/***
 * Entry point to test the CRUD operations of Register
 */
public class DbTester {

	public static void main(String[] args) {
		DButils db=new DButils();
		List<Register> lr=db.retRegs();
		Iterator<Register> itr=lr.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		
		
	}

}
