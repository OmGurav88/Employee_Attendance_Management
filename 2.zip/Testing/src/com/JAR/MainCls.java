package com.JAR;

public class MainCls {

	public static void main(String[] args) {
		MainCls cc = new MainCls();
		String u = cc.retRev("Omgurav");
		System.out.println(u);
		double dd=cc.retRoot(10);
		System.out.println(dd);
	}

}
