package practice;

public class Roommates {
	private int n;
	public int getN() {
		return n;
	}
	public void setN(int n) {
		this.n = n;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getRoom_no() {
		return room_no;
	}
	public void setRoom_no(int room_no) {
		this.room_no = room_no;
	}
	private String name;
	private int room_no;
	
	@Override
	public String toString() {
		return ("Room of : "+name+" ,Room no - "+room_no+ " nOfRoomamtes - "+n);
	}
	
}
