package com.om.cls;


/***
 * Here we compared Static /Nonstatic / final classes
 */
public class MyClass {
	
	
	/**
	 * This is the only final method of the class.
	 * @author Om Gurav
	 * 
	 */
	public final void MyMethA() {
		System.out.println("This cannot be changed");
	}
	private static final int UPS = 1000;//final means we cannot modify it further.
	//static is like constructor. this is called only for the first time only
		//when the object is created.it will execute only once.
	static{
		System.out.println("This is a static block");
	}//
	////
	//make constructor over here for the function StaticClasss and compare static
	/////
	
	/***
	 * This is the static method of the class
	 */
	public static void tester() {  // i m not going to give anything in return 
		//  For using this method u don't have to create an object
		System.out.println("This is a test method from other class");
	}
	/***
	 * This is for non static method of class
	 */
	public void testNonstatic() {
		System.out.println("This is non static class");
	
	}
	/////////////////////////////////////////////////
	/***
	 * This is a method which returns square root of first 1000 numbers;
	 * as a semicolon as delimiter
	 * @return String
	 * @author Om Gurav
	 */
	public String retSqrts() {
		String fin = "";
		for(int i=0;i<UPS;i++) {
			fin+="Sqrt("+i+")="+Math.sqrt(i)+";";
		}
		return fin;
	}
	
	/***
	 * Method to return natural logs of 1000 numbers
	 * as a semicolon delimeter
	 * @returnString
	 * @author Om Gurav
	 */
	public String retLogs() {
		String fin="";
		for(int i= 0;i<UPS;i++) {
			fin+="log("+i+")=" + Math.log(i) + ";";
		}
		return fin;
	}
	
	public double retHypotenuse(double a, double b) {
		//a= /a^2 + b^2
//		double c = Math.sqrt(a*a + b*b);
		double ans = 0.0;
		ans = Math.sqrt(Math.pow(a, 2) + Math.pow(b, 2));
		return ans;
		
	}
	
	public double AreaOfTri(double b,double h) {
		return (0.5*b*h);
	}
	
	public void findArea(double[] a1,double []a2) {
		for(int i=0;i<a2.length;i++) {
			double A = AreaOfTri(a1[i],a2[i]);
			System.out.println("#Area of triangle of :"+ A);
		}
	}
	
}
