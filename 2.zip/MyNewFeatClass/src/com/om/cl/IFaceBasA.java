package com.om.cl;

public interface IFaceBasA {

	String mySpeech();
}
