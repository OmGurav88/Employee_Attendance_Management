package com.om.cl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

public class MyClsA {
	
	static String saySomething() {  //this is overrided method . whatever method is their in IFaceA is getting replaced
		return "This is a say something method";
	}	
	public static void main(String[] args) {
//		MethodRefandLambda();// 
		Integer[] ar1= {1,2,3};
		String[] ar2= {"erre","rere","gbtb"};
		List<Cubicle>lc=new ArrayList<>();
		for(int i=0;i<ar2.length;i++) {
			Cubicle c=new Cubicle(ar1[i],ar2[i]);
			lc.add(c);
		}
		lc.stream().forEach(n->System.out.println(n.getDim()+"-"+n.getName()));
		
		
	}
	
	
	private static void MethodRefandLambda() {
		IFaceBasA bas=MyClsA::saySomething;  //this is method reference.
		System.out.println(bas.mySpeech());
		Integer[] arr= {1,2,3,4,5,6,7,8,9,10};
		
		//using Consumer and not using lambda
		Arrays.asList(arr).forEach(new Consumer<Integer>(){ 
			@Override
			public void accept(Integer t) {
				System.out.println(t);
			}
		});
		System.out.println("#".repeat(10));
		Arrays.asList(arr).stream().forEach(n->System.out.println(n));  //using lambda func
		
		String[] ar1= {"erre","rere","gbtb"};
		Arrays.asList(ar1).stream().forEach(n->System.out.println(n));
		
		Boolean[] b= {true,false,true,true,false};
		Arrays.asList(b).stream().forEach(n->System.out.println(n));
		
		Arrays.asList(b).stream().forEach(n->{
			if(n) {
				System.out.println("Its true");
			}
			else {
				System.out.println("Its false");
			}
		});
		
		Character[] ar5= {'a','b','c','d'};
		Arrays.asList(ar5).stream().forEach(n->System.out.println(n));
		Arrays.asList(ar5).stream().forEach(System.out::println);
	}

}
