package com.om.cls;

import java.io.Console;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Time;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.Scanner;

public class Main {

//	private static final String  = null;

	public static void main(String[] args) throws SQLException {
		
		EmpDAOImpl e = new EmpDAOImpl();
        Scanner sc = new Scanner(System.in);
        
        String reset = "\033[0m";  // Reset to default
        String blue = "\033[1;34m"; // Blue for headers and login success
        String red = "\033[1;31m";  // Red for errors
        String green = "\033[1;32m"; // Green for success
        String yellow = "\033[1;33m"; // Yellow for the menu title
        
        // Print welcome message with color
        System.out.println(yellow + "********** Welcome to login system **********" + reset);
        System.out.println(blue + "==============================================" + reset);
        
        // Prompt for username
        System.out.print(blue + "Enter username: " + reset);
        String username = sc.nextLine();
        System.out.println(blue + "----------------------------------------------" + reset);
        
        // Prompt for password
     // Hiding password input
        Console console = System.console();
        String password="";
        System.out.print(blue + "Enter password: " + reset);
//        String password = sc.nextLine();
        char[] passwordChars = console.readPassword();  // Password input hidden
        password = new String(passwordChars);

        
        boolean isAuthenticated = e.authenticate(username, password);

        if (isAuthenticated) {
            System.out.println(blue + "=============================================" + reset);
            System.out.println(green + "Login successful!" + reset); // Green success message
        } else {
            System.out.println(red + "Please enter valid Username and password\\nLogin Unsuccesfull" + reset); // Red error message
        }
		while(true) {
			System.out.println(yellow + "\n============== Employee Management System ==========" + reset + "\n");
	        System.out.println(green + "1. View my Profile" + reset);
	        System.out.println(green + "2. Mark Attendance" + reset);
	        System.out.println(green + "3. View Attendance History" + reset);
	        System.out.println(green + "4. Generate Report" + reset);
	        System.out.println(green + "5. Exit" + reset);
	        
	        // Prompt for user input
	        System.out.print(blue + "Enter your choice: " + reset);

            int c = sc.nextInt();
            switch(c) {
                        
            case 1: 
            	//View Details
            	System.out.println("\n============== View Profile ==========\n");
                e.viewProfile(username);
                break;
            
             
            case 2:
            	//markAttendance
      
            	System.out.println("\n============== Mark Attendance ==========\n");

            	System.out.print("Enter Employee ID: ");
 	            int e2 = sc.nextInt();

 	           LocalDate today = LocalDate.now();
 	           LocalDate date = null;

	            // Validate the entered date
	            System.out.print("Enter Attendance Date (YYYY-MM-DD): ");
	            LocalDate date1= LocalDate.parse(sc.next());
	            if (date1.isAfter(today)) {
	                System.out.println("Please enter a valid date to mark attendance. Future dates are not allowed.");
	                return; // Exit the method if the date is invalid
	            }
	            
 	            //Date date = Date.valueOf(sc.next());
 	            
 	            String checkQuery = "SELECT COUNT(*) FROM attendance WHERE emp_id = ? AND a_date = ?";
                 
 	           LocalTime checkIn = null, checkOut = null;
               while (true) {
                   try {
                       System.out.print("Enter Check-In Time (HH:MM:SS): ");
                       checkIn = LocalTime.parse(sc.next());

                       System.out.print("Enter Check-Out Time (HH:MM:SS): ");
                       checkOut = LocalTime.parse(sc.next());

                       // Validate logical order
                       if (checkOut.isBefore(checkIn)) {
                           System.out.println("Check-Out time must be after Check-In time. Please re-enter.");
                           continue; // Re-prompt for times
                       }
                       break; // Valid times entered
                   } catch (Exception e1) {
                       System.out.println("Invalid time format. Please enter times in HH:MM:SS format.");
                   }
               }
                   e.markAttendance(e2, date1, checkIn, checkOut, checkQuery);
   	            	break;
               
 	            
 	          

            	
            case 3:
            	//View Attendance
            	System.out.println("\n============== Attendance Report ==========\n");
                System.out.print("\nEnter Employee ID: ");
                int empId = sc.nextInt();
                System.out.print("Enter Start Date (yyyy-mm-dd): ");
                Date startDate = Date.valueOf(sc.next());
                System.out.print("Enter End Date (yyyy-mm-dd): ");
                Date endDate = Date.valueOf(sc.next());
                e.viewAttendance(empId, startDate, endDate);
                break;
            

            case 4:
            	//generate summary
            	System.out.println("\n============== Generating report ==========\n");
            	 System.out.print("Enter Employee ID: ");
 	            int empId1 = sc.nextInt();

 	            System.out.print("Enter Month (YYYY-MM): ");
 	            String month = sc.next();

 	            String sd1 = month + "-01";
 	            String ed1 = month + "-31";
 	            e.generateSummary(empId1,month,sd1,ed1);  //int e, String m, String st, String ed
 	            break;
 	            
            case 5:
                System.out.println("\nExiting the system. Goodbye!");
                sc.close();
                return;
                
            default:
                System.out.println("Invalid choice! Please try again.");
        
            }
            }
	}
}
		
		
		


	
		
	


