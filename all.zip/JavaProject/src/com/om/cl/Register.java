package com.om.cl;

public class Register {
	private int rid;
	private String rname;
	private String rmail;
	
	public Register() {	}
	public Register(int rid,String rname,String rmail) {
		this.rid=rid;
		this.rname=rname;
		this.rmail=rmail;
	}
	public int getRid() {
		return rid;
	}
	public void setRid(int rid) {
		this.rid = rid;
	}
	public String getRname() {
		return rname;
	}
	public void setRname(String rname) {
		this.rname = rname;
	}
	public String getRmail() {
		return rmail;
	}
	public void setRmail(String rmail) {
		this.rmail = rmail;
	}
	
}
