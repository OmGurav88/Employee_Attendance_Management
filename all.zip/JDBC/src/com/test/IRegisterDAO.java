package com.test;

import java.util.List;

public interface IRegisterDAO {
	
	public List<Register> retRegs();
	public Register retReg(int id);
	public String insReg(Register r);
	public String upReg(Register r);
	public String delReg(Register r);
	
}
