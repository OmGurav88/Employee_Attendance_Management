package com.test;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.util.Properties;

public class TesterMain {

	public static void main(String[] args) throws IOException {
		
//			FileReader reader = new FileReader(new File("C:\\Users\\localadmin\\eclipse-workspace\\JDBC\\src\\app.properties"));
//			Properties props = new Properties();
//			props.load(reader);
//			System.out.println(props.getProperty("drivername"));
//			System.out.println(props.getProperty("conn"));
//			System.out.println(props.getProperty("username"));
//			System.out.println(props.getProperty("password"));
//			System.out.println(props.getProperty("tabname"));
			IRegisterDAOImpl impl = new IRegisterDAOImpl();
			List<Register> lr = impl.retRegs();
			for(Register r:lr) {
				System.out.println(r);
			}
			System.out.println(impl.retReg(5));
			
			
		
	}
}
