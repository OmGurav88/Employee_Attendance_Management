package com.test;


/***
 * POJO class to capture the row information from the table
 * @author OmGurav
 */
public class Register {
	
	public Register() {
		
	}
	
	/***
	 * Overloaded constructor for the class
	 * @param rid primary key
	 * @param rname name 
	 * @param rimage this is email 
	 */
	public Register(int rid, String rname, String rimage) {
		super();
		this.rid = rid;
		this.rname = rname;
		this.rimage = rimage;
	}
	
	private int rid;
	private String rname;
	public int getRid() {
		return rid;
	}
	public void setRid(int rid) {
		this.rid = rid;
	}
	public String getRname() {
		return rname;
	}
	public void setRname(String rname) {
		this.rname = rname;
	}
	public String getRimage() {
		return rimage;
	}
	public void setRimage(String rimage) {
		this.rimage = rimage;
	}
	private String rimage;
	
	@Override
	public String toString() {
		return this.rid +" "+this.rname+" "+this.rimage;
	}
}
