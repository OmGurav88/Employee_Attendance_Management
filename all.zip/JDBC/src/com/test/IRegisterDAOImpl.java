package com.test;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Properties;

public class IRegisterDAOImpl implements IRegisterDAO {

	
	static Properties props=null;
	
	static {
		try {
			FileReader reader = new FileReader(new File("C:\\\\Users\\\\localadmin\\\\eclipse-workspace\\\\JDBC\\\\src\\\\app.properties""));
			Properties props = new Properties();
			props.load(reader);
			System.out.println(props.getProperty("drivername"));
			System.out.println(props.getProperty("conn"));
			System.out.println(props.getProperty("username"));
			System.out.println(props.getProperty("password"));
			System.out.println(props.getProperty("tabname"));
			
//			static Properties props=null;
//			static Connection conn=null;
//			static {
//				try {
//					FileReader reader=new FileReader(new File("C:\\\\Users\\\\localadmin\\\\eclipse-workspace\\\\JDBC\\\\src\\\\app.properties"));
//					props=new Properties();
//					props.load(reader);
//					Class.forName(props.getProperty("drivername"));
//					conn=DriverManager.getConnection(props.getProperty("conn"), props.getProperty("username"), props.getProperty("password"));
//				} catch (IOException | ClassNotFoundException | SQLException e) {
//					e.printStackTrace();
//				}
//			
//			
//		} catch (FileNotFoundException e) {
//			e.printStackTrace();
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
		
	}
	
	@Override
	public Register retReg(int id) {
//		return null;
		String query = "select * from "+props.getProperty("tabname")+" where rid = ?";
		Register r = null;
		
		PreparedStatement ps = conn.prepareStatement(query);
		ps.setInt(1, id);
		ResultSet rs = ps.executeQuery();
		while(rs.next()) {
			r=new Register(rs.getInt(1),rs.getString(2),rs.getString(3));
		}
	}

	@Override
	public String insReg(Register r) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String upReg(Register r) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String delReg(Register r) {
		// TODO Auto-generated method stub
		return null;
	}

}
