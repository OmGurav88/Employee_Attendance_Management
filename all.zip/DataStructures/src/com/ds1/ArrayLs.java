package com.ds1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
import java.util.Stack;

public class ArrayLs {

	public static void main(String[] args) {
		
//		ArrayList a1 = new ArrayList();
//		for(int i =0;i<10;i++) {
//			a1.add("String " + (i+1));
//		}
//		System.out.println(Arrays.deepToString(a1.toArray()));
		
		//upper --> reverse --> then store
		StringBuilder str = new StringBuilder();
		
		
		ArrayList a1 = new ArrayList();
		Scanner sc = new Scanner(System.in);
		String ans = "y";
		int i=1;
		while(ans.equalsIgnoreCase("y")) {
			
			System.out.print("Enter String -  ");
			String a=sc.nextLine();
			String str1 = a.toUpperCase();
			/*
			 * char[] arr1 = str1.toCharArray();
		Stack stk = new Stack();
		for(char c : arr1) {
			stk.push(c);
		}
		while(!(stk2.isEmpty())) {
			;
		}
			 */
			
			System.out.println("Enter y to continue: ");
			ans=sc.nextLine();
		}
		System.out.println("###############################");
		for(Object a:a1) {
			System.out.println(a);
		}
		System.out.println("###############################");
		
	}

}
