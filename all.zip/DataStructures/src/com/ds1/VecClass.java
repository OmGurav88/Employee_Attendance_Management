package com.ds1;

import java.util.Vector;

public class VecClass {

	public static void main(String[] args) {
		Vector vec = new Vector();
		for(int i=0;i<1000;i++) {
			String j = "Sqrt("+(i+1)+")="+Math.sqrt(i+1);
			vec.add(j);
		}
		
		int i = vec.size();
		int j=0;
		while(j<i) {
			System.out.println(vec.toArray()[j]);
			j++;
		}
		
		
	}

}
