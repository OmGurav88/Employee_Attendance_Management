package com.HashSet;

import java.util.Scanner;
import java.util.Stack;

public class prog1 {

	public static void main(String[] args) {
//		String s = "OMPRAKASHGURAV";
		Scanner sc = new Scanner(System.in);
		String s2 = sc.nextLine();
		
//		System.out.println(ch);
		char[] arr1 = s2.toCharArray();
		Stack st = new Stack();
		for(char c : arr1) {
			st.push(c);
		}
		while(!(st.isEmpty())) {
			System.out.print(st.pop());
		}
		
	}

}
