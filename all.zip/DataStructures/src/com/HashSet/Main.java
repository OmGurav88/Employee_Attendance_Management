package com.HashSet;

import java.util.HashSet;
import java.util.TreeSet;

public class Main {

	public static void main(String[] args) {
		
//		firstRun();
		
//		int[] arr = {21,21,212,32,32,44,4,1,22,44,2,4};
//		//sorted as well as remove duplicates
//		TreeSet set = new TreeSet();
//		for(int a:arr) {
//			set.add(a);
//		}
//		System.out.println(set);
		
		char[] ch = {'z','y','a','A','f','m','a','b','b','Z','r'};
		TreeSet s2 = new TreeSet();
		for(char c : ch) {
			s2.add(c);
		}
		System.out.println(s2);
		
	}

	private static void firstRun() {
		int[] arr = {1,1,1,1,1,1,2,2,2,2,2,6,6,3,3,5,5,5,5,9,7,7,77,7,7};
		HashSet hs = new HashSet();
		for(int i : arr) {
			hs.add(i);
		}
		System.out.println(hs);
		//also try with char float double string
		
		//char array
		char[] ch = {'a','a','a','b','b'};
		HashSet hs1 = new HashSet();
		for(char c : ch) {
			hs1.add(c);
		}
		System.out.println(hs1);
		
		//float 
		Float[] ch = {1.1f,1.2f,1.1f,1.1f,1.2f,1.3f};
		HashSet hs1 = new HashSet();
		for(char c : ch) {
			hs1.add(c);
		}
		System.out.println(hs1);
		
		//Linkedhashset is slow , remove duplicates, it do hashes, it converts it into LL, thats why it is slow
//		LinkedHashSet hs2 = new LinkedHashSet();
//		for(char c : ch) {
//			hs2.add(c);
////		}
//		System.out.println(hs2);
		
		//for object , we have to use interface for this comparison
	}

}
