package com.om;

import java.util.Arrays;
import java.util.Scanner;
import java.util.Stack;

public class Main {

	public static void main(String[] args) {
//		Stack s = new Stack();
//		String[] ar = {"om","Risheel","kartik"};
//		for(int i=0;i<ar.length;i++) {
//			s.add(ar[i]);
//		}
//		while(!(s.isEmpty())) {
//			System.out.println(s.pop());
//		}
		//String-->Char Array-->Put in stack
		String s1 = "Mohan is a good boy";
//		Scanner sc = new Scanner(System.in);
//		System.out.println("Enter the string to be reversed : ");
//		String j = sc.nextLine();
//		
//		char[] arr1 = j.toCharArray();
//		Stack stk2 = new Stack();
//		for(char c : arr1) {
//			stk2.push(c);
//		}
//		while(!(stk2.isEmpty())) {
//			System.out.print(stk2.pop());
//		}
		
//		Scanner sc = new Scanner(System.in);
//		String s1 = sc.nextLine();
		char[] chAr = s1.toCharArray();
//		System.out.println(chAr);
		Stack st = new Stack();
		for(char c : chAr) {
			st.push(c);
		}
		while(!(st.isEmpty())) {
			System.out.print(st.pop());
		}
		
		
		
		
		
	}

}
