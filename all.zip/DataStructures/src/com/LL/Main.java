package com.LL;

import java.util.LinkedList;

public class Main {

	public static void main(String[] args) {
//		LLfirst();
		
//		LinkedList<Integer> ll = new LinkedList<Integer>();
//		LinkedList<Float> ll = new LinkedList<Float>();
		LinkedList<Double> ll = new LinkedList<Double>();
		
		for(int i=0;i<1000;i++) {
//			ll.add(i);
			ll.add((double)((i+1)+0.5));
		}
//		for(Object j:ll) {
//			System.out.println(j);
//		}
		
		LinkedList<Character> llc = new LinkedList<Character>();
		llc.add('a');
		llc.add('b');
		llc.add('c');
		System.out.print(llc);
		//copy other primitive LL from notepad
		
		
	}

	
	
	private static void LLfirst() {
		LinkedList<String> ll = new LinkedList<String>();
		String arr[] = {"Om","Raja","KKK","Rahul"};
		for(String s:arr) {
			ll.addFirst(s);  //like a stack
//			ll.addLast(s); //like a queue
//			ll.add(s); //like an array
		}
		
//		System.out.println(ll);
//		for(Object j:ll) {
//			System.out.println(j);
//		}
		
		int i =0;
		int size = ll.size();
		while(i<size) {
			System.out.println(ll.get(i++));
		}
	}

}
