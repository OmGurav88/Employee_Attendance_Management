package com.Interface;

public abstract class BasCls {
	public abstract String retRev(String a);
	public void retA() {
		System.out.println("Non abstract method");
	}
	public void retB() {
		System.out.println("Second Non abstract method");
		
	}
	
	
}
