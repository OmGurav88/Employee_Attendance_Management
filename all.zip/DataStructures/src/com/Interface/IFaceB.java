package com.Interface;

public interface IFaceB {
	public String retRvStr(String a);
	public String retUpStr(String a);
}
