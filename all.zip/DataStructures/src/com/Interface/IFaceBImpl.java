package com.Interface;

public class IFaceBImpl implements IFaceB {

	@Override
	public String retRvStr(String a) {
		return null;
	}

	@Override
	public String retUpStr(String a) {
		return null;
	}

}
