package com.Interface;

import java.util.Hashtable;

public class Main {

	public static void main(String[] args) {
//		IFaceB facb =new IFaceB() {
//			@Override
//			public String retRvStr(String a) {
//				return a.toUpperCase();
//			}
//			@Override
//			public String retUpStr(String a) {
//				StringBuilder strb = new StringBuilder();
//				strb.append(a);
//				strb.reverse(a);
//				return strb.toString(a);
//			}
		
		    BasCls ba = new BasCls() {
			
			@Override
			public String retRev(String a) {
				return (new StringBuilder(a).reverse().toString());
			}
			
			@Override
			public void retA() {
				super.retA();
			}};
			
			ba.retA();
			ba.retB();
			String ba2 = ba.retRev("Omgurav");
			System.out.println(ba2);
		/////////////////////////////////////////////////////////////////
		
		
		int [] a1 = {1,2,3,4};
		String[] a2 = {"P","NP","GP","A"};
		Hashtable<Integer, String> ht = new Hashtable<>();
		for(int i=0;i<a2.length;i++) {
			ht.put(a1[i], a2[i]);
		}
		System.out.println(ht);
		
		}	
		
	}


