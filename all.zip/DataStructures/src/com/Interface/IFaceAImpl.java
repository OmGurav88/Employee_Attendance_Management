package com.Interface;

public class IFaceAImpl implements IFaceA {

	@Override
	public void methA() {
		System.out.println("MethA Called ")
	}

	@Override
	public void methB() {
		System.out.println("MethB Called ")
	}

	@Override
	public void methC() {
		System.out.println("MethC Called ")
	}

}
