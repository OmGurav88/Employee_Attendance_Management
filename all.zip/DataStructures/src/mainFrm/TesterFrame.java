package mainFrm;

import java.awt.FlowLayout;

public class TesterFrame {

	public static void main(String[] args) {
		MainFrm frm = new MainFrm();
		
		frm.setDefaultCloseOperation(2);
		frm.setVisible(true);
		frm.setLayout(new FlowLayout());
		frm.setSize(500,500);
	}

}
