package mainFrm;

import java.awt.Container;
import java.util.Vector;

import javax.swing.JComboBox;

public class MainFrm extends JFrame{
	public MainFrm() {
		Container cont = getContentPane();
		Vector vec = new Vector();
		for (int i=0;i<100;i++) {
			vec.add("Log(" + i + ")=" + Math.log(i);
		}
		JComboBox box = new JComboBox(vec);
		cont.add(box);
	}
}
