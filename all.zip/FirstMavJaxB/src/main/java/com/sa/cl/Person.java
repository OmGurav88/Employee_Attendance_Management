package com.sa.cl;

public class Person {
	private int pid;
	private String pname
}
