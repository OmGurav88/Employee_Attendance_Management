package com.om.cl;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class MyClsC {

	public static void main(String[] args) {
		//print first 20 even numbers
		Stream.iterate(1, e->e+1).filter(a->a%2==0).limit(20).forEach(System.out::println);  
		System.out.println("*".repeat(20));
		//Store result into a list and print it
		var aList=Stream.iterate(1, a->a+1).filter(a->a%2!=0).limit(30).collect(Collectors.toList());
		aList.forEach(System.out::println);
		
		var aList1=Stream.iterate(1, a->a+1).filter(a->a%3==0).limit(30).collect(Collectors.toList());
//		aList1.forEach(System.out::println);
		System.out.println(aList1);
		
		//
		Integer arr1[]= {12,13,14,15,16,17,18,19,20};
		String[] arr2 = {"Stringa","Stringb","Stringc","Stringd","Stringe","Stringf","Stringg","Stringh","Stringi"};
		int k=0;
		List<Cubicle> lsc=new ArrayList<>();
		for(Integer a:arr1) {
			lsc.add(new Cubicle(a,arr2[k]));
			k++;
		}
		var aa=lsc.stream().map(n->n.getDim()).collect(Collectors.toList());
		aa.stream().forEach(System.out::println);
		
		aa.parallelStream().forEach(System.out::println);
		
		
	}

}
