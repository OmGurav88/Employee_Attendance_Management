package com.om.cls;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

public class StrUtilsClsTestCase {

	StrUtilsCls cls=null;
	
	@Before  //e
	public void setUp() throws Exception {
		cls=new StrUtilsCls();
	}

	@After
	public void tearDown() throws Exception {
		cls=null;
	}

	@Test
	public void testRetStrUp() {
		String y="ABC";
		assertEquals(y,cls.retStrUp("abc"));
	}

	@Test
	public void testRetStrLow() {
		String y="abc";
		assertEquals(y,cls.retStrLow("ABC"));
	}
	
	@Ignore //to ignore the test case in Juni testing
	@Test
	public void testRetRev() {
		String s="OmGrav";
		assertEquals(s,cls.retRev("varuGmO"));
	}

}
