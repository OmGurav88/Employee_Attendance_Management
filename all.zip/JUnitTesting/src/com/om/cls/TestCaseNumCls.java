package com.om.cls;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

public class TestCaseNumCls {

	NumCls nc = null;
	@Before
	public void setUp() throws Exception {
		nc=new NumCls();
	}

	@After
	public void tearDown() throws Exception {
		nc=null;
	}

	@Test
	public void testRetSqrt() {
		double d=2.0;
		assertEquals(d, nc.retSqrt(4),0.0);
		
	}

	@Test
	public void testRetLogs() {
		double d=1.0;
		assertEquals(d, nc.retLogs(10),0.0);
	}
	@Ignore
	@Test
	public void testRetPow() {
		int p=4;
		assertEquals(p, nc.ret);
	}

	@Test
	public void testRetArr() {
		Double[] arr= {1.0,2.0,3.0,4.0};
		assertArrayEquals(arr, nc.retArr());
	}

	@Test
	public void testRetArra() {
		Double[] dr= {1.5,2.5,3.5,4.5};
		assertArrayEquals(dr, nc.retArra(new int[] {1,2,3,4}));
	}

	@Test
	public void testRetList() {
		List ll=Arrays.asList(1,2,3,4,5);
		assertArrayEquals(ll.toArray(), nc.retList().toArray());
		
	}
	
	@Test
	public void testSqrRootAr() {
		List<Double> ls=new ArrayList<>();
		ls=Stream.iterate(1.0,a->Math.sqrt(a)).limit(5).toList();
		assertArrayEquals(ls.toArray(), nc.retSqrRootList().toArray());
		
	}

}
