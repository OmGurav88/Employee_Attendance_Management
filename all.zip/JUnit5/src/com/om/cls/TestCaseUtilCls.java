package com.om.cls;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class TestCaseUtilCls {

	UtilCls u =null;


	@BeforeEach
	void setUp() throws Exception {
		u=new UtilCls();
	}
	
	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void testRetSub() {
		String k="Sanakra";
		String s1="Omkar";
		String s2="Ra";
//		assertEquals(k.substring(0, 3).length(), u.retSub(k).length());
		assertEquals(s1.substring(0, 3).length(), u.retSub(s2).length()); 
	}

}
