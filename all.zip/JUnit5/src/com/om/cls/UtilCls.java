package com.om.cls;

public class UtilCls {
	
	public String retSub(String a) {
		String j="";
		if(a.length()>3) {
			j=a.substring(0,3);
		}
		else {
			j=a.toUpperCase();
		}
		return j;
	}
	
}
