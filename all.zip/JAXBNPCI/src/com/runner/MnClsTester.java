package com.runner;

import com.mar.BMarshal;

public class MnClsTester {

	public static void main(String[] args) {
		BMarshal b=new BMarshal();
		b.retXmlBook();
	}

}
