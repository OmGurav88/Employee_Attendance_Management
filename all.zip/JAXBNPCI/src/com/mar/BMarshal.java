package com.mar;

import java.io.StringReader;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.PropertyException;

import com.mods.Books;

public class BMarshal {
	public void retXmlBook() {
		String fin="";
		JAXBContext context = null;
		
		try {
			context=JAXBContext.newInstance(Books.class);
			Marshaller marshal=context.createMarshaller();
			Books b=new Books(212,"Quiet siegh of morr","Salman Rushdie");
			marshal.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
			StringReader sa=null;
			marshal.marshal(b, System.out);
		} catch (PropertyException e) {
			e.printStackTrace();
		} catch (JAXBException e) {
			e.printStackTrace();
		}
		
	}
}
