package com.om.cls;

public class BankAccount {
	private String bankIdl;
	private String bankName;
	private String actName;
	
	public BankAccount() {
		
	}
	public BankAccount(String a, String b, String c) {
		
		this.bankIdl = a;
		this.bankName = b;
		this.actName = c;
	}

	@Override
	public String toString() {
		return "BankAccount [bankIdl=" + bankIdl + ", bankName=" + bankName + ", actName=" + actName + "]";
	}
}
