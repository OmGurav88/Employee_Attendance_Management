package com.om.cls;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
//import java.util.Arrays;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Consumer;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class MnCls {

	public static void main(String[] args) {
		ApplicationContext cont = new ClassPathXmlApplicationContext("applicationContext.xml");
		
//		Books b = (Books)cont.getBean("booka");
//		System.out.println(b.getId() +" "+ b.getBname()+" " + b.getBauth());
////		
//		BankAccount ba = (BankAccount)cont.getBean("bact");
//		System.out.println(ba.toString()); 
////		
//		LedgerBook lb = (LedgerBook)cont.getBean("Ledgehome");
//		System.out.println(lb);
//		
//		////////////////
//		Employee em = (Employee)cont.getBean("chdbean");
//		System.out.println(em);
//		
//		EmpChild emc = (EmpChild)cont.getBean("empchild");
//		System.out.println(emc.getPid()+"-"+emc.getPemail()+"-"+emc.getPname());
////		System.out.println(emc);
//		
////		.args..args...args.clone().clone()..args.clone().clone()..
//		ChdClassforBasCls cls=(ChdClassforBasCls)cont.getBean("chdc");
//		System.out.println(cls.retRoot(100));
//		System.out.println(cls.getEmailid()+" & "+cls.getMobile());
//		
//		ChdIFaceA ca = (ChdIFaceA)cont.getBean("chda");
//		System.out.println(ca.retDtr("omgurav"));
//		System.out.println(ca.retDouble());
//		System.out.println(ca.retStra("Helloooooo"));
		
//		forArrays(); //for array injection inside beans
		
		//for lists injection inside beans
//		ListInjection();
		
		//map injection
		MapInjection();
		
		
		
	}

	private static void MapInjection() {
		ApplicationContext ctx=new ClassPathXmlApplicationContext("applicationContext.xml");
		FirstCls cls = (FirstCls)ctx.getBean("firstcls");
		System.out.println(cls.getIdenStr());
		Map<Integer, String> map=cls.getMyMap();
		
		//1st method to print
//		Iterator itr=map.entrySet().iterator();
//		while(itr.hasNext()) {
//			Entry<Integer, String> ent = (Entry)itr.next();
//			System.out.println(ent.getKey()+" "+ent.getValue());
//		}
		
		//2nd method to print
//		List ls=Arrays.asList(map.entrySet());
//		ls.forEach(new Consumer<Object>()){
//			@Override
//			public void accept(Object t) {
//				System.out.println(t);
//			}
//			
//		}
//	}

	private static void ListInjection() {
		ApplicationContext ctx=new ClassPathXmlApplicationContext("applicationContext.xml");
		Department dept = (Department)ctx.getBean("depta");
		System.out.println(dept.getDeptid()+"-"+dept.getDeptname());
		dept.getLprofs().stream().forEach(new Consumer<Professor>() {
			@Override
			public void accept(Professor t) {
				System.out.println(t);
			}
		});
	}

	private static void forArrays() {
		ApplicationContext ctx=new ClassPathXmlApplicationContext("applicationContext.xml");
		University univ=(University)ctx.getBean("univa");
		System.out.println(univ.getuName());
		Arrays.asList(univ.getsList()).stream().forEach(new Consumer<Student>() {
			@Override
			public void accept(Student t) {
				System.out.println(t);
			}
		});
	}

}