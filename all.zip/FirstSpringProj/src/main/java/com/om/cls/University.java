package com.om.cls;

public class University {
	private String uName;
	public String getuName() {
		return uName;
	}
	public void setuName(String uName) {
		this.uName = uName;
	}
	public Student[] getsList() {
		return sList;
	}
	public void setsList(Student[] sList) {
		this.sList = sList;
	}
	private Student[] sList;
	
	
	
}
