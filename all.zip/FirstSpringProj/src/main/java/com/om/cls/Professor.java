package com.om.cls;

public class Professor {
	private String pname;
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getPbranch() {
		return pbranch;
	}
	public void setPbranch(String pbranch) {
		this.pbranch = pbranch;
	}
	private String pbranch;
	@Override
	public String toString() {
		return "Professor [pname=" + pname + ", pbranch=" + pbranch + "]";
	}
}
