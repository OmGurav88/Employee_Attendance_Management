package com.om.cls;

public class ChdIFaceA implements IFaceA {

	@Override
	public String retDtr(String s) {
		// TODO Auto-generated method stub
		return s.toUpperCase();
	}

	@Override
	public double retDouble() {
		// TODO Auto-generated method stub
		return 88;
	}
	@Override
	public String retStra() {
		// TODO Auto-generated method stub
		return "Default Method";
	}

}
