package com.om.cls;

public class EmpChild extends Employee{

}
