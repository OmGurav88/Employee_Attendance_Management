package com.om.cls;

public class ChdClassforBasCls extends BasClass {

	@Override
	public String retRoot(int a) {
		// TODO Auto-generated method stub
		return "Root is "+Math.sqrt(a);
	}

}
