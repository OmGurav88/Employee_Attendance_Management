package com.om.cls;

import java.util.Map;

public class FirstCls {
	private String idenStr;
	private Map<Integer, String> myMap;
	
	public String getIdenStr() {
		return idenStr;
	}
	public void setIdenStr(String idenStr) {
		this.idenStr = idenStr;
	}
	public Map<Integer, String> getMyMap() {
		return myMap;
	}
	public void setMyMap(Map<Integer, String> myMap) {
		this.myMap = myMap;
	}
	
}
