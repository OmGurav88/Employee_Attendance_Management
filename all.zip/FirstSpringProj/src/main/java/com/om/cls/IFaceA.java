package com.om.cls;

public interface IFaceA {
	default String retDtr(String a) {
		return a.toUpperCase();
		}
	public String retStra();
	public double retDouble();
}
