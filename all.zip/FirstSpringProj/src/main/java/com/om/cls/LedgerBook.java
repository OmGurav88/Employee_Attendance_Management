package com.om.cls;

public class LedgerBook {
	
	private int leId;
	private int quatity;
	private String leItem;
	private String leCat;
	public LedgerBook() {
		
	}
	public LedgerBook(int quatity, String leItem) {
		super();
		this.quatity = quatity;
		this.leItem = leItem;
	}
	public int getLeId() {
		return leId;
	}
	public void setLeId(int leId) {
		this.leId = leId;
	}
	public String getLeCat() {
		return leCat;
	}
	public void setLeCat(String leCat) {
		this.leCat = leCat;
	}
	
	@Override
	public String toString() {
		return "LedgerBook [leId=" + leId + ", quatity=" + quatity + ", leItem=" + leItem + ", leCat=" + leCat + "]";
	}
}
