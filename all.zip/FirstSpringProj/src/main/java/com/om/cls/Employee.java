package com.om.cls;

public class Employee extends Person {
	private String eOrg;
	public String geteOrg() {
		return eOrg;
	}
	public void seteOrg(String eOrg) {
		this.eOrg = eOrg;
	}
}