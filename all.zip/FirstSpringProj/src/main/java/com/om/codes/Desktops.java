package com.om.codes;

public class Desktops {
	private int id;
	private String name;
	private String brand;
	
	public Desktops() {
		
	}
	public Desktops(int a, String b,String c) {
		this.id=a;
		this.name=b;
		this.brand=c;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	
	
	
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Desktops [id=");
		builder.append(id);
		builder.append(", name=");
		builder.append(name);
		builder.append(", brand=");
		builder.append(brand);
		builder.append("]");
		return builder.toString();
	}
}
