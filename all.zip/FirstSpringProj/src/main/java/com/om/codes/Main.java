package com.om.codes;
//do this if u dont want to use beans; without using application context

public class Main {

	public static void main(String[] args) {
		
		DeskConfig config = new DeskConfig();
		Desktops desk=(Desktops)config.retDesk();
		System.out.println(desk.toString());
				
		
	}

}
