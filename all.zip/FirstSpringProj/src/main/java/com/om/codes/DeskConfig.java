package com.om.codes;

public class DeskConfig {
	
	public Desktops retDesk() {
		//do this if u dont want to use beans; without using application context
		Desktops ds=new Desktops(21,"Gateways Computers","Brother"); 
		return ds;
	}
}
