package com.Anno;

import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;
//Anotation is file read by compiler.

@Retention(RUNTIME)
@Target(TYPE)
public @interface MyAnnoClass {
	String retDesc() default "";
	int retPrio() default 990;
}
