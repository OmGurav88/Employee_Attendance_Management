package com.Anno;

public class Main {

	public static void main(String[] args) {
		BankAccount ba = new BankAccount();
		MyAnnoClass ma=ba.getClass().getAnnotation(MyAnnoClass.class);
		System.out.println(ma.retDesc());
		System.out.println(ma.retPrio());
	}

}
