package com.Anno;

@MyAnnoClass(retDesc = "Bank Account Class",retPrio=96550)
public class BankAccount {
	private int bid;
	public BankAccount() {
		
	}
	public BankAccount(int bid, String bName, String aHname) {
		super();
		this.bid = bid;
		this.bName = bName;
		AHname = aHname;
	}
	public int getBid() {
		return bid;
	}
	public void setBid(int bid) {
		this.bid = bid;
	}
	public String getbName() {
		return bName;
	}
	public void setbName(String bName) {
		this.bName = bName;
	}
	public String getAHname() {
		return AHname;
	}
	public void setAHname(String aHname) {
		AHname = aHname;
	}
	private String bName;
	private String AHname;
	
}
