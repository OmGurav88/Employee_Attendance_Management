package com.person;


import java.lang.reflect.Method;


public class Main {

	public static void main(String[] args) {
		//Field Annotation for person class
//		person p = new person();
//		for(Field field:p.getClass().getDeclaredFields()) {	
			
//			MyAnno af = (MyAnno) field.getAnnotation(MyAnno.class);
//			System.out.println(af);
//			String fin=String.format("Field:%s\n Annotation Value:%s \n",field.getName(), af);
//			System.out.println(fin);
//			
//			//Class Annotation for person
//			person ba = new person();
//			MyAnnoClass ma=ba.getClass().getAnnotation(MyAnnoClass.class);
//			System.out.println(ma.retDesc());
			
			//Method Annotation for Book class
		
//			Books b =new Books();
//			for(Method m:b.getClass().getDeclaredMethods()) {
//				MyMethAnno am = (MyMethAnno)m.getAnnotation(MyMethAnno.class);
////				System.out.println(am.descMeth());
//				String fin = String.format("Name of the method:%s\nAnnotation of the method:%s\n", m.getName(),am.descMeth());
//				System.out.println(fin);
//				
//			}
			
		}
	}

}
