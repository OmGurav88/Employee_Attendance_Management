package com.person;

import com.Anno.MyAnnoClass;

@MyAnnoClass(retDesc = "Person Class")
public class person {
	@MyAnno(descField="Govt ID of the person")
	private int pid;
	@MyAnno(descField="Name of the person")
	private String pname;
	@MyAnno(descField="Email of the person")
	private String pmail;
	@MyAnno(descField="Mobile no. of the person")
	private String pmob;
	
	public String getPmob() {
		return pmob;
	}
	public void setPmob(String pmob) {
		this.pmob = pmob;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getPmail() {
		return pmail;
	}
	public void setPmail(String pmail) {
		this.pmail = pmail;
	}
	
	
}
