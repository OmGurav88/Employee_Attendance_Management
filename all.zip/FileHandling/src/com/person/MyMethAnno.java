package com.person;

import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;
//Books POJO
@Retention(RUNTIME)
@Target(METHOD)
public @interface MyMethAnno {
	String descMeth() default "";
}
