package com.person;

public class Books {
	
	@MyMethAnno(descMeth = "This is a annotation for retDets method in books")
	public String retDets() {
		return "This is a class describing library";
	}
	@MyMethAnno(descMeth = "This is a annotation for retBookFirst method in books")
	public String retBookFirst() {
		return "Adventures of Om gurav";
	}
}
