package com.MyCls;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

//File handling code will not work in linnux, it is case sensitive .Linux is case sensitive
public class MyMain implements IFaceConst {

	public static void main(String[] args) throws IOException {
//		creaFile(); //to create a new file in the specified path

//		creaDir();  //to create a new directory in the specified path.

//		listFilesofFolder();
		
//		creaSqrtDatafile();  //FileOutputStream used to write data to a file
		
//		readFile(); //reading from a file
		
		///////////////////////////Bank Account  and Anno class test//////////////////////
		
		
		
	}

	private static void readFile() throws FileNotFoundException, IOException {
		String fname = "sqrtfile.txt";
		String op="";
		FileInputStream fis = new FileInputStream(new File(paths+fname));
		int y=0;
		while((y=fis.read())!=-1) {
			op+=(char)y;
		}
		System.out.println(op);
		fis.close();
	}

	private static void creaSqrtDatafile() throws FileNotFoundException, IOException {
		String fname = "sqrtfile.txt";
		String fin="";
		for(int i=1;i<1001;i++) {
			fin+="Sqrt("+i+")="+Math.sqrt(i)+";\n";
		}
		File f = new File(paths+fname);
		FileOutputStream fos=new FileOutputStream(f);
		fos.write(fin.getBytes());
		fos.flush();
		fos.close();
		System.out.println("Done writing to the file");
	}

	private static void listFilesofFolder() {
		File ff = new File("C:\\Users\\localadmin\\eclipse-workspace\\DataStructures\\src\\mainFrm\\");
		String[] ar = ff.list();
		for (String j : ar) {
			if (j.indexOf(".txt") > 0) {

			} else {
				System.out.println(j);
			}
			if (j.indexOf(".xml") > 0) {

			} else {
				System.out.println(j);
			}
		}
	}

	private static void creaDir() {
		String dname = "MyDirTest";
		String dnamer = "MyDirOmFolder"; // for renaming the dname dir
		File f = new File(paths + dname);
		f.mkdir();
//		f.renameTo(new File(paths + dnamer));  //to rename
	}

	private static void creaFile() {
		String myfile = "Tester.txt";
		File file = new File(paths + myfile);

		try {
			file.createNewFile();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
