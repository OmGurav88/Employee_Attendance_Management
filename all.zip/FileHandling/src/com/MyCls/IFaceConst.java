package com.MyCls;

public interface IFaceConst {
	public static final String paths = "C:\\Users\\localadmin\\Documents\\NPCIBootcamp\\";
}
