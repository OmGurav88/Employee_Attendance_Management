package com.om.cl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class MyClsB {

	//Inline functions
		public static void main(String[] args) {
			
			//this function
			Function<Integer,Double> sqrtFun=(a)->Math.sqrt(a);
			System.out.println(sqrtFun.apply(2));
			Function<Integer,Double> sqrFun=(a)->Math.pow(a, 2);
			System.out.println(sqrFun.apply(21));
			
			Function<String,String> retRev=(a)->(new StringBuffer(a)).reverse().toString();
			System.out.println(retRev.apply("Omgurav"));
			
			//For three parameters
			BiFunction<Integer,Integer,Double> retHypo=(a,b)->Math.hypot(a,b);
			System.out.println(retHypo.apply(3, 4));
			
			//for bunch of functions
			Function<Integer,Double> funa=(a)->Math.pow(a, 2);
			Function<Double,Double> funb=(b)->Math.sqrt(b);
			
			//Composition of these two function  Run funa and then run funb
			var fund=funa.andThen(funb);  //var is used without knowing the outputs data type.
			System.out.println(fund.apply(2));
			
			//and operator
			Function<Integer,Double> fune=(a)->Math.pow(a, 2);
			Function<Double,Double> funf=(b)->Math.log(b);
			var myVal=fune.andThen(funf);
			System.out.println(myVal.apply(4));

			//predicate returns either true or false; not both ; it is boolean condition
			Predicate<Integer> appred=(a)->a>10;
			int k =100;
			System.out.println(appred.test(k));
			
			Predicate<String> astr=(a)->a.length()>0;
			System.out.println(astr.test("Omgurav"));
			System.out.println(astr.test(""));
			
			String[] ar1 = {"Om","","gurav","rahul"};
			//combine predicate with iterator
			Arrays.asList(ar1).stream().forEach(n->{
				if(astr.test(n)) {
					System.out.println(n);
				}
			});
			
			//composition of predicates
			Predicate <Integer> cpred=(a)->a%2==0; //print even numbers
			Integer[] ar3= {2,3,4,5,6,7};
			Arrays.asList(ar3).stream().forEach(n->{
//				System.out.println(cpred.test(n));
				if(cpred.test(n)) {
					System.out.println(n);
				}
			});
			
			Predicate<Integer> dpred=a->a<10;
			Predicate<Integer> epred=a->a>5;
			var fpred=dpred.and(epred);  //works as and operator
			var x=17;
			System.out.println(fpred.test(x));
			var y=8;
			System.out.println(fpred.test(y));
			System.out.println(fpred.negate().test(y));
			
			List<String> lsa= new ArrayList<>();
			List<String> lsb= new ArrayList<>();
			lsa.add("Einstein");
			lsa.add("Ramanujan");
			lsa.add("Chandra");
			lsb.add("India");
			lsb.add("Russia");
			lsb.add("China");
			
			//BiConsumer
			BiConsumer<List<String>,List<String>> dispLists = (lista,listb)->{
				lista.stream().forEach(n->System.out.println(n.toUpperCase()));
				listb.stream().forEach(n->System.out.println(n.toUpperCase()));
			};
			dispLists.accept(lsa,lsb);
			
			//BiConsumer : It can have Biconsumer inside a biconsumer.
			BiConsumer<List<Integer>,Set<Integer>> aConsumer=(list1,set2)->{
				Set<Integer> set3=list1.stream().collect(Collectors.toSet()); //converting list to set
				Iterator<Integer> itra=set3.iterator();
				Iterator<Integer> itrb=set2.iterator();
				while(itra.hasNext()) {
					System.out.println(itra.next());
				}
				System.out.println("*".repeat(50));
				while(itrb.hasNext()) {
					System.out.println(itrb.next());
				}			
			};
			List<Integer> laa=new ArrayList<>();
			laa=Arrays.asList(21,212,22,21,22,212,12,21,12,212,56,56,56);
			Set<Integer> setaa=new HashSet<>();
			Arrays.asList(32,32,3,32,32,24,24,24,24,5,45,5,5,5);
			aConsumer.accept(laa, setaa);	
			
			//functino having multiple args without converting it into a structure.
			varyingArgs(1,9,2222,2,44);
			varyingArgs(21);
			varyingArgs(21,22,34);
			
		}
		public static void varyingArgs(Integer...a) {  //three dots is called as spread operator. //Objects 
//			Arrays.asList(a).forEach(System.out::println);  //a is assumed as an array
//			a.forEach(n->System.out.println(n));
			
		}
	}


