/**
 * 
 */
/**
 * 
 */
module MyNewFeatClass {
}