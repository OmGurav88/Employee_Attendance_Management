package com.threads;

//Threads are Async - it means not in particular order
public class Main {

	public static void main(String[] args) {
//		MyThr t = new MyThr();
//		t.start(); //using thread 
		
		MythrA t = new MythrA();
		t.run();//while using runnable interface use thread.run() method
		System.out.println("******Starting the program******");
		
		Thread aa=new Thread(new Runnable() {
			@Override
			public void run() {
					System.out.println("Inside thread!");
			}
		}) ;
		aa.start();
		new Runnable() {
			@Override
			public void run() {
				System.out.println("Another thread inside main");
			}
		}.run();
		
		new Thread(new Runnable() {
			@Override
			public void run() {
				System.out.println("Runs inside void main another thread!");
			}
		}).start();
		}
		
				
	}

}
