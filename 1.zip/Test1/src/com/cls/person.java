package com.cls;

public class person {
	private int pid;
	public int getPid() {
		return pid;
	}
	public person() {
		
	}
	public person(int pid, String pname, String pmail) {
		super();
		this.pid = pid;
		this.pname = pname;
		this.pmail = pmail;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getPmail() {
		return pmail;
	}
	public void setPmail(String pmail) {
		this.pmail = pmail;
	}
	private String pname;
	private String pmail;
	
	public int compareTo(person 0) {
		if(this.pid==o.pid) {
			
		}
	}
	
	@Override
	public String toString() {
		return this.pid + "-"+ this.pname + "-" + this.pmail;
	}
}
