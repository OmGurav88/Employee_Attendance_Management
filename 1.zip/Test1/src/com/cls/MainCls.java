package com.cls;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

public class MainCls {

	public static void main(String[] args) {
//		List<Student> ls = new ArrayList<>();
//		int[] ar1 = {2122,22,33,99};
//		String[] ar2 = {"om","ganu","ramu","teju"};
//		String [] ar3= {"om@gmail.com","ganu@gmail.com","ramu@gmail.com","teju@gmail.com"};
//		for(int i=0;i<ar1.length;i++) {
//			Student std=new Student();
//			std.setSid(ar1[i]);
//			std.setSname(ar2[i]);
//			std.setSemail(ar3[i]);
//			ls.add(std);
//		}
//		System.out.println(ls);
		
		
		//for converting our java objects to JSON object.
//		ObjectMapper om = new ObjectMapper();
//		
//			try {
//				String u = om.writeValueAsString(ls);
//				System.out.println(u);
//			} catch (JsonGenerationException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			} catch (JsonMappingException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			} catch (IOException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//			
		
		
		//using JAR
//		
//		System.out.println("**********After using comparator");
//		StudentSorter sor = new StudentSorter();
//		Collections.sort(ls,sor);
//		System.out.println(ls);
		
//		List<Employee> ls = new ArrayList<>();
//		int[] ar1 = {1,2,3,4};
//		String[] ar2 = {"om","ganu","ramu","teju"};
//		int [] ar3= {100,2000,20,500};
//		for(int i=0;i<ar1.length;i++) {
//			Employee std=new Employee();
//			std.setEid(ar1[i]);
//			std.setEname(ar2[i]);
//			std.setEsal(ar3[i]);
//			ls.add(std);
//		}
//		System.out.println(ls);
		
//		ls.sort(new Comparator<Employee>() {
//		@Override
//		public int compare(Employee o1, Employee o2) {
//			return o1.getSal()-o2.getSal();
//		}
//		Collections.sort(lsp);
//		System.out.println(lsp);
	
//		System.out.println("\n**********After using comparator**********\n");
//		StudentSorter sor = new StudentSorter();
//		Collections.sort(ls,sor);
//		System.out.println(ls);
		
//		List<person> ls = new ArrayList<>();
//		int[] ar1 = {1,2,3,4};
//		String[] ar2 = {"om","ganu","ramu","teju"};
//		String [] ar3= {"om@gmail.com","ganu@gmail.com","ramu@gmail.com","teju@gmail.com"};
//		for(int i=0;i<ar1.length;i++) {
//			person std=new person();
//			std.setPid(ar1[i]);
//			std.setPname(ar2[i]);
//			std.setPmail(ar3[i]);
//			ls.add(std);
//		}
//		System.out.println(ls);
//		
//		Collections.sort(ls);
		
		//player
		List<Player> ls = new ArrayList<>();
		int[] ar1 = {1,2,3,4};
		String[] ar2 = {"om","ganu","ramu","teju"};
		int[] ar3 = {145,23,3,49};
		String [] ar4= {"mh","kerala","tamilnadu","UP"};
		for(int i=0;i<ar1.length;i++) {
			Player std=new Player();
			std.setPid(ar1[i]);
			std.setPname(ar2[i]);
			std.setPrank(ar3[i]);
			std.setState(ar4[i]);
			ls.add(std);
		}
		System.out.println(ls);
		Collections.sort(ls, new Comparator<Player>() {
			@Override
			public int compare(Player o1, Player o2) {
				return o1.getPrank() - o2.getPrank();
			}
		});
		System.out.println(ls);
		
		
	}
		
		
		
	

}
