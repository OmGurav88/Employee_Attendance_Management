package com.del;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class MyMain {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Class.forName("org.postgresql.Driver");
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter rid to delete : ");
		int rid = sc.nextInt();
		Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/TrialDB","postgres","om");
		
//		String query = "delete from public.\"Register\" where rid="+rid;
		
		String query = "delete from public.\"Register\" where rid=?";	 //this is right method to do.	
		PreparedStatement ps = conn.prepareStatement(query);
		ps.setInt(1, rid); //this is known as template querying ; 
		ps.executeUpdate();
	}

}
