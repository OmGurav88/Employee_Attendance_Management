package com.mod.DButils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mod.Register;


/***
 * database utility class which performs crud opern on a single table register.
 * class uses static blocks to initialize the connection
 * @author OmGurav
 */
public class DButils {
	
	/**
	 * Static connection variable to be initialised in static block
	 */
	private static Connection conn=null;
	
	static {
		try {
			Class.forName("org.postgresql.Driver");
			conn=DriverManager.getConnection("jdbc:postgresql://localhost:5432/TrialDB", "postgres", "om");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	
	/**
	 * Execute a select statement on table and store the returned rows into a array list
	 * @return arraylist of register objects
	 * @author OmGurav
	 */
	public List<Register> retRegs(){
		List<Register> lr=new ArrayList<>();
		String query="select * from public.\"Register\"";
		try {
			Statement st=conn.createStatement();
			ResultSet rs=st.executeQuery(query);
			while(rs.next()) {
				Register r=new Register(rs.getInt(1), rs.getString(2), rs.getString(3));
				lr.add(r);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return lr;
	}
	
	/***
	 * inserts a new row into a register table
	 * inputs from user end
	 * @param r register class object which contains values to be inserted
	 * @return register object
	 * @author OmGurav
	 */
	public String insRec(Register r) {
		String status="Not done";
		try {
			PreparedStatement ps=conn. prepareStatement("insert into public.\"Register\" values (?,?,?)");
			ps.setInt(1, r.getRid());
			ps.setString(2, r.getRname());
			ps.setString(3, r.getRimage());
			ps.execute();
			status="Done";
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return status;
	}
	
	/***
	 * Updates the table row with the values coming from user as a register object
	 * @param r register class object is returned
	 * @return register object
	 * @author OmGurav
	 */
	public String upRec(Register r) {
		String status="Not done";
		try {
			PreparedStatement ps=conn. prepareStatement("update public.\"Register\" set rname=?,remail=? where rid=?");
			ps.setString(1, r.getRname());
			ps.setString(2, r.getRimage());
			ps.setInt(3, r.getRid());
			ps.executeUpdate();
			status="Done";
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return status;
	}
	
	/***
	 * Deletes the record of entered primary key from the table 
	 * @param key
	 * @return
	 */
	public String delRec(int key) {
		String status="Not done";
		try {
			PreparedStatement ps=conn. prepareStatement("delete from public.\"Register\" where rid=?");
			ps.setInt(1, key);
			ps.executeUpdate();
			status="Done";
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return status;
	}
	
	
	
}
