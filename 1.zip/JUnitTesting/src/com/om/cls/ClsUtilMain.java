package com.om.cls;

public class ClsUtilMain {

	public String retUtil (String u){

		String fin="";
		char[] arr=u.toCharArray();
		int i=0;
		for(char c:arr) {
			if(i%2==0) {
				fin+=String.valueOf(c).toUpperCase();
			}
			else {
				fin+=String.valueOf(c).toLowerCase();
			}
			i++;
		}
		return fin;
		
	}

}
