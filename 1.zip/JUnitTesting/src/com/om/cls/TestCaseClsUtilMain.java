package com.om.cls;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TestCaseClsUtilMain {
	
	ClsUtilMain cls=null;
	@Before
	public void setUp() throws Exception {
		cls=new ClsUtilMain();
	}

	@After
	public void tearDown() throws Exception {
		cls=null;
	}

	@Test
	public void testRetUtil() {
		String ts="SaTis";
		String j = cls.retUtil("satish");
		assertEquals(ts, j);
	}

}
