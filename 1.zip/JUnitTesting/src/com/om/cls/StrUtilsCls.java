package com.om.cls;


/***
 * Utility Class to test some string functions
 * @author OmGurav
 */
public class StrUtilsCls {
	
	/***
	 * returns an input string in uppercase
	 * @param j normal string
	 * @return uppercase string
	 */
	@Deprecated
	public String retStrUp(String j) {
		return j.toUpperCase();
	}
	
	public String retStrLow(String j) {
		return j.toLowerCase();
	}
	
	public String retRev(String j) {
		return (new StringBuffer(j).reverse().toString());
	}
}
