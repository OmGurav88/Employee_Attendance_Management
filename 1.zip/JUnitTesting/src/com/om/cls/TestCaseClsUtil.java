package com.om.cls;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TestCaseClsUtil {

	ClsUtilMain cls = null;
	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testRetUtil() {
		fail("Not yet implemented");
	}

}
