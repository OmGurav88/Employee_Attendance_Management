package com.om.cls;

import org.junit.runner.JUnitCore;
import org.junit.runner.Request;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

public class ClsUtilMainTester {

	public static void main(String[] args) {

		//command line
		Request request=Request.method(TestCaseClsUtilMain.class, "testRetUtil");
		Result res=new JUnitCore().run(request);
		for(Failure f:res.getFailures()) {
			System.out.println(f.getMessage());
		}
		System.out.println(res.getFailureCount());
	}

}
