package com.om.cls;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class NumCls {
	public double retSqrt(int a) {
		return Math.sqrt(a);
	}
	
	public double retLogs(int a) {
		return Math.log10(a);
	}
	
	public int retPow(int a,int b) {
		return (int)Math.pow(a, b);
	}
	
	public Double[] retArr() {
		return new Double[] {1.0,2.0,3.0,4.0};
	}
	
	public Double[] retArra(int[] arr) {
		Double[] dArr=new Double[arr.length];
		for(int i=0;i<arr.length;i++) {
			dArr[i]=arr[i]+0.5;
		}
		return dArr;
	}
	
	public List<Integer> retList(){
		List<Integer> ls=new ArrayList<>();
		ls=Stream.iterate(1,a->a+1).limit(5).toList();
		return ls;
	}
	//ar of sqr root of num
	public List<Double> retSqrRootList(){
		List<Double> ls=new ArrayList<>();
		ls=Stream.iterate(1.0,a->Math.sqrt(a)).limit(5).toList();
		return ls;
	}
}
