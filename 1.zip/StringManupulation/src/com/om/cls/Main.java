package com.om.cls;

import java.util.Arrays;
import java.util.List;
import java.util.StringTokenizer;

public class Main {

	public static void main(String[] args) {
		String str = "This is a test string for testing ";
		System.out.println(str);
		System.out.println(str.toUpperCase());
		System.out.println(str.toLowerCase());
		System.out.println(str.substring(0,7));
		System.out.println(str.charAt(0));
		System.out.println(str.concat(" Om's string"));
		
		//Strings are immutable in java.
		//when u perfom any string manupulation, it is not performed on original string, it is performed on a copy.
		//java cannot touch the original string.
		//in java , working with string will slow down the program.
		//Other similar DS to string are ; string buffer and string build.
		//String buffer is thread safe; String builder is not thread safe.
		//Use this DS when u have a lot of string manupulation
		//String b uilder is much faster as compared to string buffer.
		
		StringBuffer stb = new StringBuffer();
		stb.append(str);
		for(int i=0;i<26;i++) {
			stb.append((char)(i+97));
		}
		System.out.println(stb.toString());
		
		System.out.println(str);
		
		StringBuilder build = new StringBuilder();
		build.append(str.toUpperCase());
		for(int i=0;i<26;i++) {
			build.append((char)(i+97));
		}
		System.out.println(build);
		
		//how to upper case of char
		System.out.println(String.valueOf('a').toUpperCase());
		
		String ae = "34";
		System.out.println(Integer.parseInt(ae));		
		System.out.println(ae.getClass());
		
		//non static - dependent on a person who is using the class
		//static ; dependent on a class; u dont have to create an object for it.
		//
		MyClass.tester(); // here we dont created object for this class //her static block is also called 
		
		MyClass s =new MyClass();
		s.testNonstatic();
		
		MyClass st = new MyClass();
		st.MyMethA(); //public final void 
		
		String u = st.retSqrts();
//		System.out.println(u);
		
		//using spliting 
//		String[] sArr = u.split(";");
//		for(String sarr : sArr) {
//			System.out.println(sarr);
//		}
		
		//using tokenizer
		StringTokenizer sk = new StringTokenizer(u,";");
//		System.out.println(sk.countTokens()); //this will return proper count as we didnt iterated yet.
//		while(sk.hasMoreTokens()) {
//			System.out.println(sk.nextToken());  //nextToken returns string 
//		}

		//using nextElements
//		while(sk.hasMoreElements()) {
////			String us = String.valueOf(sk.nextElement());
////			System.out.println(us);
//			System.out.println(sk.nextElement()); //This returns object.
//		}
		
		System.out.println(sk.countTokens());
		
		//using for loop
//		for(int i=0;i<1001;i++) {
//			System.out.println(sk.nextElement());
//		}
		System.out.println(sk.countTokens()); ///after doing loop countToken will be zero.
//		Consider their is a pointer going forward while doing nextElement or nextToken
		
		//This return logs of 1000 numbers
//		String myStr = st.retLogs(); 
//		List<String> lst = Arrays.asList(myStr.split(";"));
//		for(String c:lst) {
//			System.out.println(c);
//		}
		
		
		double h = st.retHypotenuse(3, 4);
		System.out.println("Hypotenuse : "+ h);
		
		double h2 = st.retHypotenuse(3.3, 4.0);
		System.out.println("Hypotenuse : "+ h2);
		
		double area = st.AreaOfTri(3, 5);
		System.out.println("Area of triangle : " + area);
		
		double [] height = {1,2,3,45,6,7,8,9,5,11};
		double [] base = {1,2,3,45,6,7,8,9,5,11};
		st.findArea(height,base);
		
		
		
		
		
	
		
		
		
		
	}

}
