package practice;

public class strings {

	public static void main(String[] args) {
		String s = "Omgurav";
		Roommates r = new Roommates();
		r.setN(4);
		r.setName("Om");
		r.setRoom_no(3);
		System.out.println(r);
	}

}
